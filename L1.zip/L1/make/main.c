#include "one.h"
#include "ext.h"

int main ()
 {
  printf("main\n");
  one();
  return(1);
 }
 