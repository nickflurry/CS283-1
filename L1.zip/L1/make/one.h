#define ONE 1
#include <stdio.h>
