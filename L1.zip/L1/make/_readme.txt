make -f makefile-2.txt all
